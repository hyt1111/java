import javax.swing.*;//JFrame �N���X���܂�
import java.awt.event.*;//ActionListener �C���^�[�t�F�[�X���܂�
import java.awt.*;//Container �N���X�CFlowLayout �N���X���܂�

class JButtonSample03 extends JFrame implements ActionListener{
	JButton btn1 = new JButton("Button-1");
	JButton btn2 = new JButton("Button-2");
	JButton btn3 = new JButton("Button-3");
	
	public void actionPerformed(ActionEvent e){
		//�����ꂽ�{�^���̎Q�Ƃ�selectedButton �ɑ������
		JButton selectedButton = (JButton)e.getSource();
		if(selectedButton==btn1){
			System.out.println("Button-1 was pushed!");
		}else if(selectedButton==btn2){
			System.out.println("Button-2 was pushed!");
		}else{
			System.out.println("Button-3 was pushed!");
		}
	}
	
	JButtonSample03(){
		setSize(500, 400);
		setTitle("Frame title");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new FlowLayout());
		
		JPanel panel1 = new JPanel();
		panel1.setPreferredSize(new Dimension(200, 100));
		panel1.setLayout(new BorderLayout() );
		
		btn1.addActionListener(this);
		panel1.add(btn1,BorderLayout.NORTH);
		
		btn2.addActionListener(this);
		panel1.add(btn2,BorderLayout.CENTER);
		
		btn3.addActionListener(this);
		panel1.add(btn3,BorderLayout.SOUTH);
		
		getContentPane().add(panel1);
	}
	
	public static void main(String [] args){
		JButtonSample03 fr = new JButtonSample03();
		fr.setVisible(true);
	}
}
