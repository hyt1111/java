abstract class AbstClassSample01{

	abstract public double getArea();

}
